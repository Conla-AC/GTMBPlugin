NAMESPACE = 'ConlaCheck'
SERVER_SYSTEM_NAME = 'ConlaServer'
CLIENT_SYSTEM_NAME = 'ConlaClient'
SERVER_SYSTEM_PATH = 'Conla.ConlaServer.ConlaServerSystem'
CLIENT_SYSTEM_PATH = 'Conla.ConlaClient.ConlaClientSystem'
#By Conla
